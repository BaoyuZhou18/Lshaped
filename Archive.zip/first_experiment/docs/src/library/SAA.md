# Sample average approximation

Documentation for `StochasticPrograms.jl`'s SAA solvers.

## Index

```@index
Pages = ["SAA.md"]
```

## API

```@autodocs
Modules = [SAA]
Pages   = ["MOI_wrapper.jl"]
```
