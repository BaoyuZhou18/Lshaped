# Crash

Documentation for `StochasticPrograms.jl`'s crash methods, for use in structured solvers and sample-based solvers.

## Index

```@index
Pages = ["crash.md"]
```

## Crash methods

```@autodocs
Modules = [Crash]
Pages   = ["crash.jl"]
```
